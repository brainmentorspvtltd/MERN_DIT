module.exports = {
  STATUS_CODES: {
    SUCCESS: 200,
    RESOURCE_NOT_FOUND: 404,
    INTERNAL_SERVER_ERROR: 500,
  },
  LOGS: {
    MAX_FILES: process.env.MAXFILE,
    MAX_SIZE: process.env.MAX_SIZE,
    ERROR_LOG_FILE: process.env.ERROR_LOG_FILE,
    DEBUG_LOG_FILE: process.env.DEBUG_LOG_FILE,
  },
  ROUTES: {
    USER: {
      LOGIN: "/login",
      REGISTER: "/register",
      PROFILE: "/profile",
    },
  },
};
