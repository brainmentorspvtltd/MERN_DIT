const { SUCCESS } = require("../utils/config").STATUS_CODES;
module.exports = {
  login(request, response) {
    let userid = request.body.userid;
    let password = request.body.password;
    response.status(SUCCESS).json({ userid, password });
  },
  register(request, response) {
    let userid = request.body.userid;
    let password = request.body.password;
    let name = request.body.name;
    let phone = request.body.phone;
    response.status(SUCCESS).json({ userid, password, name, phone });
  },
  profile(request, response) {},
};
