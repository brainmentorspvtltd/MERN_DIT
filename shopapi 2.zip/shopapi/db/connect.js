const mongoose = require("mongoose");
const logger = require("../utils/logs/logger")(__filename);
mongoose.connect(
  process.env.DBURL,
  {
    maxPoolSize: process.env.POOLSIZE,
  },
  (err) => {
    if (err) {
      logger.error("DB Connection Error " + JSON.stringify(err));
    } else {
      logger.debug("Connection Created...");
    }
  }
);
