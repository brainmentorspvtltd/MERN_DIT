const express = require("express");
const { LOGIN, REGISTER, PROFILE } = require("../../../utils/config").ROUTES
  .USER;
const router = express.Router();
const userCtrl = require("../../../controllers/user");

router.post(LOGIN, userCtrl.login);
router.post(REGISTER, userCtrl.register);
router.get(PROFILE, userCtrl.profile);
module.exports = router;
