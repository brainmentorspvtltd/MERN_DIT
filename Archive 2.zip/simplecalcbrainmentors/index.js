const mul = require('./calc');
module.exports = {
    add(x,y){
        return x + y;
    },
    mul
}