
const fs = require('fs');
console.log("Before Read");
try{
const content = fs.readFileSync(__filename,{encoding:'utf8'});
console.log(content.toString());
}
catch(err){
    console.log('Error is ',err);
}
console.log("After Read");