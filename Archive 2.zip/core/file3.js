const fs = require('fs');
const fullPath = '/Users/amitsrivastava/Documents/nodejs-learn/basics/core/'+'sample.txt';
let data = "Hello this is the new content";
fs.appendFile(fullPath,data,  (err)=>{
    if(err){
        console.log('unable to write content in a file ',err);
    }
    else{
        console.log('Write done');
    }
})