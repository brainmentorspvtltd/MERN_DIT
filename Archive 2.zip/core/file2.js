const fs= require('fs');
console.log("Before Read");
fs.readFile(__filename,{encoding:'utf8'},(err,content)=>{
    if(err){
        console.log('Error During File Read ',err);
    }
    else{
        console.log(content.toString());
    }
});
console.log("After Read ");