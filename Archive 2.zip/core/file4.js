
const fs = require('fs');
const path = require('path');
const parentPath = path.normalize(__dirname+'/..');
const fullPath = path.join(parentPath,'movies/movie.mkv');
const cloneLoc = path.join(parentPath,'movies/movie2.mkv');
// const fullPath = path.join(__dirname,'movies/movie.mkv');
// const cloneLoc = path.join(__dirname,'movies/movie2.mkv');
//const path  = '/Users/amitsrivastava/Documents/nodejs-learn/basics/core/movies/movie.mkv';
//const path2  = '/Users/amitsrivastava/Downloads/movie2.mkv';
console.log('Before Read');
const stream = fs.createReadStream(fullPath);
const wstream = fs.createWriteStream(cloneLoc);
stream.on('open',()=>console.log("Stream is Open"));
stream.pipe(wstream);
// stream.on('data',chunk=>{
//     console.log("Rec Chunk ",chunk);
//     wstream.write(chunk);
// });  
stream.on('end',()=>console.log("copy done"));
stream.on('close',()=>console.log("Stream Close"));
stream.on('error',err=>console.log(err));
// fs.readFile(path,(err, content)=>{
//     if(err){
//         console.log('Unable to read this file',err);
//     }
//     else{
//         console.log(content);
//     }
// });
console.log('After Read');