const obj = require('simplecalcbrainmentors');
console.log(obj.add(10,20));
console.log(obj.mul(10,20));