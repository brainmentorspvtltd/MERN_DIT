export const obj = {
    add(x,y){
        return x + y;
    }
}
