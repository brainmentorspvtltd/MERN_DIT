module.exports = {
    mul(x,y){
        return x * y;
    }
}