import {obj} from './one.js';
console.log(obj.add(10,20));
const o = require('./three');
console.log(o.mul(1,4));