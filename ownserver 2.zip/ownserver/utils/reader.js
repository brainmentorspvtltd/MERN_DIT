const { isBuffer } = require('util');

function staticContentReader(request, response){
    let url = request.url;
    if(url.endsWith(".css")){
        response.writeHead(200,{'content-type':'text/css'});
    }
    else{
        response.writeHead(200,{'content-type':'text/html'});

    }
    if(url == '/'){
        url = '/index.html';
    }
    //console.log("URL is ",url);
    const fs = require('fs');
const path = require('path');
const parent = path.normalize(__dirname+"/..");
const fullPath = path.join(parent,`public/${url}`);
//console.log(fullPath);
const readStream = fs.createReadStream(fullPath);
readStream.pipe(response);

}
module.exports = staticContentReader;

