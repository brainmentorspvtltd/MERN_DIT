const http  = require('http');
const https = require('https');
const dotenv = require('dotenv');
const chalk = require('chalk');
const staticContent  = require('./utils/reader');
const urlMod = require("url");
const qs = require('querystring');
const fs = require('fs');

dotenv.config();
function handleRequestResponse(request, response){
    const url = request.url;
    const method = request.method;
    console.log(url, method);
    response.writeHead(200,{'content-type':'text/html'});
    if(url.startsWith("/login?") && method =='GET'){
        const queryString = urlMod.parse(url,true);
        let userid = queryString.query.userid;
        let password = queryString.query.pwd;
        if(userid === password){
            response.write("Welcome "+userid);
        }
        else{
            response.write("Invalid Userid or Password");
        }
        //response.write("U r in Login Action");
        response.end();
    }
    else
    if(url==='/login' && method ==='POST'){
        let body = '';
        request.on('data',chunk=>{
            body+=chunk;
        });
        request.on('end',()=>{
            const userInfo = qs.parse(body);
            if(userInfo.userid === userInfo.pwd){

                response.writeHead(301,{'Location':'/dashboard'});

                response.end();
                //response.write("Welcome "+userInfo.userid);
            }
            else{
                response.write("Invalid Userid or Password");
                response.end();
            }

        })
    }
    else
    if(url==='/dashboard' && method ==='GET'){
        request.url = '/dashboard.html';
        staticContent(request,response);
    }
    else{

    staticContent(request,response);
    }
    // response.write("<html><body>");
    // response.write("<h1>hello client.....</h1>");
    // response.write("</body></html>");
    // response.end();
}
const certOptions = {
    key:fs.readFileSync('./cert/key.pem'),
    cert:fs.readFileSync('./cert/cert.pem')
}
const server = https.createServer(certOptions, handleRequestResponse);
server.listen(process.env.PORT || 1234,(err)=>{
    if(err){
        console.log(chalk.red.bold('Unable to start the server'),chalk.red(err));
    }
    else{
        console.log(chalk.green.italic('Server Started '),chalk.yellow(server.address().port));
    }
})