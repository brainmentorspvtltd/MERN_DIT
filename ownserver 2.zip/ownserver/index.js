let prices = [555,333,222,1111];
let total = 0;

for(let i = 0; i<=prices.length; i++){
    total += prices[i];
    //console.log(total, prices[i]);
}

console.log(total);
