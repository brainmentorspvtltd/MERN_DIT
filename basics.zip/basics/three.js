const fs = require('fs'); // File System
const path = '/Users/amitsrivastava/Documents/nodejs-learn/hello.txt';
console.log("Before Read");
fs.readFile(path, (error, buffer)=>{
    if(error){
        console.log("Error is ", err);
    }
    else{
        console.log('Content is ', buffer.toString());
    }
})
console.log("After Read");