// function add(a=0,b=0){
//     return a + b;
// }
// function subtract(a=0, b=0){
//     return a - b;
// }


module.exports = {
    add(a=0,b=0){
       return a + b;
   },
    sub:function(a=0, b=0){
       return a - b;
   }
}
//module.exports = opr;

// const opr = {
//      add(a=0,b=0){
//         return a + b;
//     },
//      sub:function(a=0, b=0){
//         return a - b;
//     }
// }
// module.exports = opr;
// module.exports.add = add;
// module.exports.sub = subtract;
