//const add = require('./one');
const opr = require('./calc/one');
let result = opr.add(10,20);
console.log('Add Result is ',result);
console.log('Sub result is ', opr.sub(100,200));