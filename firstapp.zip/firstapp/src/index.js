import App from './App';
import ReactDOM from 'react-dom';
let div = document.getElementById('root');
ReactDOM.render(<App/>,div);