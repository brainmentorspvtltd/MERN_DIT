import React from "react";
import './App.css';
function App(){
    const title = 'Hello ReactJS';
    const myStyle = {
        color:'green',
        backgroundColor:'blue'
    };
    // let h1 =  React.createElement('h1',null,'Hello REACT DEMO')
    // let p = React.createElement('p', null, 'I am a P Tag');
    // return React.createElement('div', null,h1,p);
    // return React.createElement('div',{className:'red'},
    // React.createElement('h1',{style:myStyle},title),
    // React.createElement('p',null,'Hi React'))
    return (<div className='red'>
        <h1 style={myStyle}>{title}</h1>
        <p>Hi ReactJS</p>
    </div>)
}
export default App;