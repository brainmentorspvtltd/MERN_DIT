const TODO_OPERATIONS = {
    tasks:[],
    getTasks(){
        return this.tasks;
    },
    convert({id, name, desc, date,url, pr}){
        let todo = new Todo(id, name, desc, date, url,pr);     
         this.tasks.push(todo);
         
     },
    add({tid, name, desc, date,url, pr}){
       let todo = new Todo(tid, name, desc, date, url,pr);     
        this.tasks.push(todo);
        return todo;
    },
    remove(){
            this.tasks = this.tasks.filter(task=>!task.markedDelete);
            return this.tasks;
    },
    searchById(id){
        return this.tasks.find(task=>task.id == id);
    },
    countUnMark(){
        return this.tasks.length - this.countMark();
    },

    countMark(){
        return this.tasks.filter(task=>task.markedDelete).length;
    },
    update(){

    },
    sort(){

    },
    read(){
        
    }
    
}