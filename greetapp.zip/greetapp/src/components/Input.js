export const Input = ({txt,name,input})=>{
    let placeHolder = `Type ${txt}`;

    return (
     <div className='form-group'>
    <label>{txt}</label>
    <input onChange={(event)=>{
        input(event,name);
    }} className='form-control' type='text' placeholder={placeHolder}/>
    </div>
    );
}