export const Operations = (props)=>{
    let myStyle = `btn ${props.myclass}`;

    return (<button onClick={props.call} className={myStyle}>{props.text} </button>)
}