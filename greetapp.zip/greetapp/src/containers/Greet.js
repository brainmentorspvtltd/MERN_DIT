import React, { Component } from "react"
import { Input } from "../components/Input"
import { Operations } from "../components/Operations"
import { Output } from "../components/Output"
import { Title } from "../components/Title"
export class Greet extends Component {
    constructor(){
        super();
        this.inputs = {
            "first":"",
            "last":""
        }
        this.message = '';
        this.state = {message : this.message, a:10, b:20};
        console.log("State ", this.state);

    }
    // aMiT
    properCase(str){
        return str.charAt(0).toUpperCase() + str.substring(1).toLowerCase();
    }
    sayWelcome(){

        let firstName = this.properCase(this.inputs['first']);
        let lastName = this.properCase(this.inputs['last']);
        this.message = `Welcome ${firstName} ${lastName}`;
        this.setState({...this.state, message:this.message});
        console.log(this.message);

    }
    takeInput(event,key){
        //console.log('Rec Event ',event.target.value, 'Key ',key, ' This is ', this.inputs);
        this.inputs[key]= event.target.value;
        //console.log("Greet Input Fn call ",this.inputs);
    }
    render(){
        console.log("Render Called...")
        return (<div className='container'>
        <Title/>
        <Input name="first" input={this.takeInput.bind(this)} txt="First Name"/>
        <Input name="last"  input={this.takeInput.bind(this)} txt="Last Name"/>
        <br/>
        <Operations call={this.sayWelcome.bind(this)} myclass="btn-primary" text="Greet"/> &nbsp;
        <Operations myclass="btn-secondary" text="Clear All"/>
        <Output msg= {this.state.message}/>
    </div>)
    }
}
/*
export const Greet = ()=>{
    return (<div className='container'>
        <Title/>
        <Input txt="First Name"/>
        <Input txt="Last Name"/>
        <br/>
        <Operations myclass="btn-primary" text="Greet"/> &nbsp;
        <Operations myclass="btn-secondary" text="Clear All"/>
        <Output/>
    </div>)
}*/