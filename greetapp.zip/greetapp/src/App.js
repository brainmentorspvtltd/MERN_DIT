import { Greet } from "./containers/Greet"

export const App = ()=>{
    return (
        <Greet/>
    );
}