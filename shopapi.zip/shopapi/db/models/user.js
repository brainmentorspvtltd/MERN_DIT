/**
 * User Schema
 * @author Amit Srivastava
 * @version 1.0
 * @copyright Brain Mentors
 *
 */