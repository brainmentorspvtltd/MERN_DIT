/**
 * This is the Application file , all the middleware settings are here
 * Server is start from Here
 * @author Amit Srivastava
 * @version 1.0
 * @copyright Brain Mentors
 */
const express = require('express');
const app = express();
const dotenv = require('dotenv');
const morgan = require('morgan');
const serverLogStream = require('./utils/logs/serverlogger');
app.use(morgan('combined',{stream:serverLogStream}));
dotenv.config();
const server= app.listen(process.env.PORT || 1234,err=>{
    if(err){
        console.log()
    }
    else{

    }
})