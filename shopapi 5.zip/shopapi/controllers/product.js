const productOperations = require("../db/services/product_operations");
module.exports = {
  async addProduct(request, response) {
    let productData = request.body;
    try {
      let doc = await productOperations.add(productData);
      response.status(200).json({ doc: doc });
    } catch (err) {
      response.status(500).json({ err: err });
    }
  },
};
