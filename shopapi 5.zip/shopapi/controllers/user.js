const { SUCCESS, INTERNAL_SERVER_ERROR } =
  require("../utils/config").STATUS_CODES;
const errorUtil = require("../utils/errorutils");
const messageBundle = require("../locales/en.json");
const userOperations = require("../db/services/user_operations");
const logger = require("../utils/logs/logger")(__filename);
const mail = require("../utils/mails/email");
const jwt = require("../utils/token");
const roleOperations = require("../db/services/role_operations");
const rightOperations = require("../db/services/right_operations");
module.exports = {
  dashBoard(request, response) {
    console.log(request.user);
    response.send("DashBoard");
  },
  async login(request, response) {
    let email = request.body.userid;
    let password = request.body.password;
    try {
      const document = await userOperations.find({ email, password });

      if (document && document.email) {
        // get rights
        let roleid = document.roleid._id;
        const rights = await rightOperations.findByRoleId(roleid);
        // role and right
        // const roleDoc = await roleOperations.findById(document.roleid);
        const token = jwt.generateToken(email);
        response.status(SUCCESS).json({
          message: messageBundle["user.login.success"],
          token: token,
          doc: document,
          rights: rights,
        });
      } else {
        response
          .status(SUCCESS)
          .json({ message: messageBundle["user.login.invalid"] });
      }
    } catch (err) {
      logger.error(errorUtil(err));
      response
        .status(INTERNAL_SERVER_ERROR)
        .json({ message: messageBundle["user.login.fail"] });
    }
    //response.status(SUCCESS).json({ userid, password });
  },
  register(request, response) {
    let email = request.body.userid;
    let password = request.body.password;
    let name = request.body.name;
    let phone = request.body.phone;
    let roleid = request.body.roleid;
    const userObject = { email, password, name, phone, roleid };
    const promise = userOperations.add(userObject);
    promise
      .then((document) => {
        if (document && document.email) {
          mail()
            .then((result) =>
              response.status(SUCCESS).json({
                message: messageBundle["user.register.success"],
                msg: result,
              })
            )
            .catch((err) => {
              logger.error(errorUtil(err));
              response
                .status(INTERNAL_SERVER_ERROR)
                .json({ message: messageBundle["user.register.fail"] });
            });
        } else {
          response
            .status(SUCCESS)
            .json({ message: messageBundle["user.register.fail"] });
        }
      })
      .catch((err) => {
        logger.error(errorUtil(err));
        //logger.error(err.stack + err.code + err.message);
        //logger.error(JSON.stringify(err));
        //console.log(JSON.stringify(err));

        response
          .status(INTERNAL_SERVER_ERROR)
          .json({ message: messageBundle["user.register.fail"] });
      });
  },
  profile(request, response) {},
};
