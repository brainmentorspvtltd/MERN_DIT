/**
 * This is a Product Schema
 * @author Amit Srivastava
 * @version 1.0
 * @copyright Brain Mentors
 *
 */
const mongoose = require("../connect");
const { PRODUCT_SCHEMA } = require("../../utils/config").SCHEMAS;
const { Schema, SchemaTypes } = mongoose;
const ProductSchema = new Schema({
  name: { type: SchemaTypes.String },
  id: { type: SchemaTypes.Number },
  descr: { type: SchemaTypes.String },
  url: { type: SchemaTypes.String },
  price: { type: SchemaTypes.Number },
});
const ProductModel = mongoose.model(PRODUCT_SCHEMA, ProductSchema);
module.exports = ProductModel;
