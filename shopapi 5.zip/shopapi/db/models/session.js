/**
 * This is a User Schema
 * @author Amit Srivastava
 * @version 1.0
 * @copyright Brain Mentors
 *
 */
const mongoose = require("../connect");
const { SESSION_SCHEMA, USER_SCHEMA } = require("../../utils/config").SCHEMAS;
const { Schema, SchemaTypes } = mongoose;
const SessionSchema = new Schema({
  sessionid: { type: SchemaTypes.String, unique: true, required: true },
  userid: { type: SchemaTypes.ObjectId, ref: USER_SCHEMA },
  date: { type: SchemaTypes.String },
});
const SessionModel = mongoose.model(SESSION_SCHEMA, SessionSchema);
module.exports = SessionModel;
