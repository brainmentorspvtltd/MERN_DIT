const mongoose = require("../connect");
const { Schema, SchemaTypes } = mongoose;
const { ACTIVE, ROLE_SCHEMA, RIGHT_SCHEMA } =
  require("../../utils/config").SCHEMAS;
const rightSchema = new Schema({
  name: { type: SchemaTypes.String, required: true, unique: true },
  descr: { type: SchemaTypes.String },
  status: { type: SchemaTypes.String, default: ACTIVE },
  url: { type: SchemaTypes.String, required: true },
  roleid: { type: SchemaTypes.ObjectId, ref: ROLE_SCHEMA },
});
var RightModel = mongoose.model(RIGHT_SCHEMA, rightSchema);
module.exports = RightModel;
