const RightModel = require("../models/rights");
module.exports = {
  async add(right) {
    return await RightModel.create(right);
  },
  async find(name) {
    return await RightModel.findOne({ name: name });
  },
  async findByRoleId(roleid) {
    return await RightModel.find({ roleid: roleid });
  },
};
