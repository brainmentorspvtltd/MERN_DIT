/**
 * This is for Product CRUD Operations
 * @author Amit Srivastava
 * @version 1.0
 * @copyright Brain Mentors
 */
const ProductModel = require("../models/product");

module.exports = {
  async add(user) {
    return await ProductModel.create(user);
  },
};
