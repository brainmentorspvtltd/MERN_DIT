const RoleModel = require("../models/role");
module.exports = {
  async add(role) {
    return await RoleModel.create(role);
  },
  async find(name) {
    return await RoleModel.findOne({ name: name });
  },
  async findById(id) {
    return await RoleModel.findOne({ _id: id });
  },
};
