const SessionModel = require("../models/session");
module.exports = {
  async add(sessionObject) {
    try {
      return await SessionModel.create(sessionObject);
    } catch (err) {
      throw err;
    }
  },
  async findBySessionId(tokenId) {
    return await SessionModel.findOne({ sessionid: tokenId });
  },
  async findByUserId(userid) {
    return await SessionModel.findOne({ userid: userid });
  },
};
