const bcrypt = require("bcrypt");
module.exports = {
  SALT: 10,
  encrypt(plainPassword) {
    return bcrypt.hashSync(plainPassword, this.SALT);
  },
  comparePassword(plainPassword, dbPassword) {
    return bcrypt.compareSync(plainPassword, dbPassword);
  },
};
