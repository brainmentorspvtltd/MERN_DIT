const passport = require("passport");
const facebookStrategy = require("passport-facebook").Strategy;
const tokenOpr = require("../token");
const userOperations = require("../../db/services/user_operations");
const sessionOperations = require("../../db/services/session_operations");
passport.use(
  new facebookStrategy(
    {
      clientID: process.env.CLIENT_ID,
      clientSecret: process.env.CLIENT_SECRET,
      callbackURL: process.env.CALLBACK_URL,
      profileFields: ["id", "displayName", "photos", "email"],
    },
    async function (token, refreshToken, profile, done) {
      try {
        let facebookId = profile.id;
        let doc = await userOperations.findByFaceBookId(facebookId);
        if (!(doc && doc.facebookid)) {
          const userObject = {
            facebookid: facebookId,
            name: profile.displayName,
            photo: profile.photos[0].value,
            email: profile.emails[0].value,
          };
          doc = await userOperations.addOAuth(userObject);
        }
        console.log("##########DOC IS ", doc);
        // create session
        const tokenId = tokenOpr.generateToken(
          profile.emails[0].value,
          profile.displayName,
          profile.photos[0].value
        );
        const sessionObject = {
          sessionid: tokenId,
          userid: doc._id,
          date: Date.now().toString(),
        };
        doc = await sessionOperations.findByUserId(doc._id);
        if (!(doc && doc.userid)) {
          doc = await sessionOperations.add(sessionObject);
        }
        // console.log("Session is ", session);
        console.log("Profile ::: ", profile);
      } catch (err) {
        return done(err, null);
        console.log(err);
      }
      return done(null, profile);
    }
  )
);
passport.serializeUser(function (user, done) {
  console.log("User is ", user);
  return done(null, user);
});
passport.deserializeUser(function (user, done) {
  console.log("USER DE ", user);
  return done(null, user);
});
