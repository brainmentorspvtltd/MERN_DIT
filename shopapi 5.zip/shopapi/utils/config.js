module.exports = {
  STATUS_CODES: {
    SUCCESS: 200,
    RESOURCE_NOT_FOUND: 404,
    INTERNAL_SERVER_ERROR: 500,
  },
  LOGS: {
    MAX_FILES: process.env.MAXFILE,
    MAX_SIZE: process.env.MAX_SIZE,
    ERROR_LOG_FILE: process.env.ERROR_LOG_FILE,
    DEBUG_LOG_FILE: process.env.DEBUG_LOG_FILE,
  },
  ROUTES: {
    USER: {
      LOGIN: "/login",
      REGISTER: "/register",
      PROFILE: "/profile",
      DASHBOARD: "/dashboard",
    },
    OAUTH: {
      FACEBOOK: {
        LOGIN: "/auth/facebook",
        CALLBACK_URL: "/fb/callback",
      },
    },
  },
  SCHEMAS: {
    ACTIVE: "A",
    SESSION_SCHEMA: "sessions",
    USER_SCHEMA: "users",
    ROLE_SCHEMA: "roles",
    RIGHT_SCHEMA: "rights",
    PRODUCT_SCHEMA: "products",
  },
};
