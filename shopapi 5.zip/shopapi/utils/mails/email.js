const nodeMailer = require("nodemailer");

async function sendMail() {
  let transport = nodeMailer.createTransport({
    service: process.env.MAIL_SERVICE,
    auth: {
      user: process.env.MAIL_USERID,
      pass: process.env.MAIL_PASSWORD,
    },
  });
  const attachments = [
    {
      path: "/Users/amitsrivastava/Documents/learn-express/shopapi/attachments/dp.jpg",
      filename: "dp.jpg",
    },
  ];
  const mailOptions = {
    from: process.env.MAIL_USER,
    to: "amit.shashi.srivastava@gmail.com",
    subject: "Congrats U Register SuccessFully",
    text: "Hello User Welcome User",
    attachments: attachments,
  };
  try {
    await transport.sendMail(mailOptions);
    return "Mail Send It";
  } catch (err) {
    console.log(err);
  }
}
module.exports = sendMail;
