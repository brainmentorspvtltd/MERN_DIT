export const productOperations = {
  products: [],
  addProduct(product) {
    this.products.push(product);
    return this.products.length;
  },
  getProducts() {
    return this.products;
  },
  totalMarked() {
    return this.products.filter((product) => product.marked).length;
  },
  mark(id) {
    let currentProduct = this.products.find((product) => product.id == id);
    currentProduct.marked = !currentProduct.marked;
    return currentProduct.marked;
  },
};
