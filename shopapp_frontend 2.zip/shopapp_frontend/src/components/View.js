import React, { useEffect, useState } from "react";
import { productOperations } from "../services/product_operations";
import { Counts } from "./view-comp/Counts";
import { Items } from "./view-comp/Items";
import { Operations } from "./view-comp/Operations";

export const View = (props) => {
  console.log("PROPS ::: ", props);
  const query = new URLSearchParams(props.location.search);
  console.log("Query String ");
  for (let param of query.entries()) {
    console.log(param);
  }
  const [products, setProducts] = useState([]);
  const [total, setTotal] = useState(0);
  const [markTotal, setMarkTotal] = useState(0);
  useEffect(() => {
    console.log("View Component Loaded..");
    let prods = productOperations.getProducts();
    setProducts(prods);
    setTotal(prods.length);

    //total = 10;
  }, []);
  const getMarkCount = (markTotal) => {
    console.log("########get marked count ", markTotal);
    setMarkTotal(markTotal);
  };
  const printProducts = (products) => {
    return (
      <>
        <Operations />
        <Items getMarkCount={getMarkCount} items={products} />
      </>
    );
  };

  return (
    <div className="container">
      <Counts total={total} markTotal={markTotal} />
      {/* <h1>Total Items are {total}</h1> */}
      {total == 0 ? <p>No record found</p> : printProducts(products)}
    </div>
  );
};
