import React from "react";

export const Counts = ({ total, markTotal }) => {
  return (
    <>
      <h3>
        Total Records {total} Marked Records {markTotal} Unmarked Records
      </h3>
    </>
  );
};
