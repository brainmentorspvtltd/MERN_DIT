import React, { useState } from "react";
import { ItemOperations } from "./item_operations";

export const Item = (props) => {
  const [color, setColor] = useState("alert-info");
  const toggleMarking = (flag) => {
    flag == true ? setColor("alert-danger") : setColor("alert-info");
  };
  return (
    <div className={color}>
      <p>Name {props.item.name}</p>
      <p>Desc {props.item.desc}</p>
      <p>Price {props.item.price}</p>
      <ItemOperations
        getMarkCount={props.getMarkCount}
        toggleMarking={toggleMarking}
        pid={props.item.id}
      />
    </div>
  );
};
