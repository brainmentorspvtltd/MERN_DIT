import React from "react";
import { productOperations } from "../../services/product_operations";

export const ItemOperations = ({ pid, toggleMarking, getMarkCount }) => {
  const marking = () => {
    let marked = productOperations.mark(pid);
    toggleMarking(marked);
    getMarkCount(productOperations.totalMarked());
  };
  return (
    <>
      <button className="btn btn-success">Edit</button>
      <button onClick={marking} className="btn btn-danger">
        Delete
      </button>
    </>
  );
};
