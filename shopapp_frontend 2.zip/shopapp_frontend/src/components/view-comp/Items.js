import React from "react";
import { Item } from "./Item";

export const Items = (props) => {
  return (
    <>
      {props.items.map((item) => (
        <Item getMarkCount={props.getMarkCount} item={item} />
      ))}
    </>
  );
};
