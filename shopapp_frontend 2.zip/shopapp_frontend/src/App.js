import logo from "./logo.svg";
import "./App.css";
import { DashBoard } from "./containers/DashBoard";

function App() {
  return <DashBoard />;
}

export default App;
