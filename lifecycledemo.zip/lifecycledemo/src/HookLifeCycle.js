import React, { useEffect } from "react";
export const HookLifeCycle = React.memo(({ data }) => {
  useEffect(() => {
    console.log("Component Did Mount");
  }, []);
  useEffect(() => {
    console.log("Component Did Update");
  }, [data]);
  useEffect(() => {
    return () => {
      console.log("Component Will UnMount");
    };
  }, []);
  return <h1>Hook Life Cycle {data}</h1>;
});
