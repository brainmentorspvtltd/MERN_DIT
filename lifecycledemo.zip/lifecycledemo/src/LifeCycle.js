import React from "react";
export class LifeCycle extends React.PureComponent {
  constructor(props) {
    super(props);
    console.log("1. Constructor Call");
  }
  UNSAFE_componentWillMount() {
    // Server Call
    console.log("2. Component Will Mount");
  }
  render() {
    console.log("3. Render Call");
    return (
      <>
        <p>Life Cycle Demo {this.props.data}</p>
      </>
    );
  }
  componentDidMount() {
    // Server Call / API Calls/ AJAX
    // Event Listeners
    // Timers / Intervals
    console.log("4. Component Did Mount Called...");
  }
  // Updation Phase

  UNSAFE_componentWillReceiveProps() {
    console.log("1. Updation Phase Component WillRec Props");
  }
  componentDidUpdate() {
    console.log("2. Component Did Update Call");
  }
  componentWillUnmount() {
    // resource clean up
    // event bind remove
    // timer stop
    // network call cancel
    console.log("Component Will UnMount Call");
  }
  //   shouldComponentUpdate(nextProps, nextState){
  //       if(this.state.x === nextState.x){
  //           return false; // No Re-render
  //       }
  //       return true;
  //   }
}
