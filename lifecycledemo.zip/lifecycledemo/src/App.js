import logo from "./logo.svg";
import "./App.css";
import { LifeCycle } from "./LifeCycle";
import { useEffect, useState } from "react";
import { HookLifeCycle } from "./HookLifeCycle";

function App() {
  const [data, setData] = useState("");
  const takeIt = (event) => {
    setData(event.target.value);
  };

  return (
    <>
      <input
        type="text"
        placeholder="Type to Share the Data"
        onChange={takeIt}
      />
      {data.length > 3 ? <h1>Comp Gone</h1> : <HookLifeCycle data={data} />}
      {/* {data.length > 3 ? <h1>Comp Gone</h1> : <LifeCycle data={data} />} */}
    </>
  );
}

export default App;
