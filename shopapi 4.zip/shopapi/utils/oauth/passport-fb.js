const passport = require("passport");
const facebookStrategy = require("passport-facebook").Strategy;
const tokenOpr = require("../token");
passport.use(
  new facebookStrategy(
    {
      clientID: process.env.CLIENT_ID,
      clientSecret: process.env.CLIENT_SECRET,
      callbackURL: process.env.CALLBACK_URL,
      profileFields: ["id", "displayName", "photos", "email"],
    },
    function (token, refreshToken, profile, done) {
      console.log("Profile ::: ", profile);
      tokenOpr.generateToken(
        profile.emails[0].value,
        profile.displayName,
        profile.photos[0].value
      );
      return done(null, profile);
    }
  )
);
passport.serializeUser(function (user, done) {
  console.log("User is ", user);
  return done(null, user);
});
passport.deserializeUser(function (user, done) {
  console.log("USER DE ", user);
  return done(null, user);
});
