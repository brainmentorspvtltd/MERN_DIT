const fs = require('fs');
const path = require('path');
const parentPath = path.normalize(__dirname+"/../..");
const fullPath = path.join(parentPath,process.env.SERVER_LOG_LOCATION);
const serverLogStream = fs.createWriteStream(fullPath,{interval:'7d'});
module.exports = serverLogStream;