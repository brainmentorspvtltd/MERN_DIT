const jwt = require("jsonwebtoken");

module.exports = {
  generateToken(emailId, name = "", photo = "") {
    return jwt.sign(
      { email: emailId, name: name, photo: photo },
      process.env.JWT_SECRET,
      {
        expiresIn: "1h",
      }
    );
  },
  verifyToken(tokenId) {
    let decoded = jwt.verify(tokenId, process.env.JWT_SECRET);
    return decoded;
  },
};
