module.exports = (err) =>
  `Trace ${err.stack} Code ${err.code} Message ${err.message}`;
