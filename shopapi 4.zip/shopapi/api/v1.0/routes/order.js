const express = require("express");
const router = express.Router();
router.get("/history", (request, response) => {
  response.send("History");
});
module.exports = router;
