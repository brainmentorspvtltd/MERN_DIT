const express = require("express");
const passport = require("passport");
const { LOGIN, REGISTER, PROFILE, DASHBOARD } = require("../../../utils/config")
  .ROUTES.USER;
const { FACEBOOK } = require("../../../utils/config").ROUTES.OAUTH;

const router = express.Router();
const userCtrl = require("../../../controllers/user");

router.post(LOGIN, userCtrl.login);
router.post(REGISTER, userCtrl.register);
router.get(PROFILE, userCtrl.profile);
router.get(
  FACEBOOK.LOGIN,
  passport.authenticate("facebook", { scope: "email,user_photos" })
);
router.get(
  FACEBOOK.CALLBACK_URL,
  passport.authenticate("facebook", {
    successRedirect: DASHBOARD,
    failureRedirect: "/",
  })
);
router.get(DASHBOARD, userCtrl.dashBoard);
module.exports = router;
