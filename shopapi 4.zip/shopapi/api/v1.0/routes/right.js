const express = require("express");
const router = express.Router();
const rightCtrl = require("../../../controllers/right");
router.post("/add-right", rightCtrl.addRight);
module.exports = router;
