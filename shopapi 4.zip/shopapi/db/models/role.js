const mongoose = require("../connect");
const { Schema, SchemaTypes } = mongoose;
const { ACTIVE, ROLE_SCHEMA } = require("../../utils/config").SCHEMAS;
const roleSchema = new Schema({
  name: { type: SchemaTypes.String, required: true, unique: true },
  descr: { type: SchemaTypes.String },
  status: { type: SchemaTypes.String, default: ACTIVE },
});
var RoleModel = mongoose.model(ROLE_SCHEMA, roleSchema);
module.exports = RoleModel;
