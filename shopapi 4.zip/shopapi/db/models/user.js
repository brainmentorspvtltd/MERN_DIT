/**
 * This is a User Schema
 * @author Amit Srivastava
 * @version 1.0
 * @copyright Brain Mentors
 *
 */
const mongoose = require("../connect");
const { USER_SCHEMA, ROLE_SCHEMA } = require("../../utils/config").SCHEMAS;
const { Schema, SchemaTypes } = mongoose;
const UserSchema = new Schema({
  email: { type: SchemaTypes.String, required: true, unique: true },
  password: { type: SchemaTypes.String, required: true },
  name: { type: SchemaTypes.String, required: true },
  phone: { type: SchemaTypes.String },
  roleid: { type: SchemaTypes.ObjectId, ref: ROLE_SCHEMA },
});
const UserModel = mongoose.model(USER_SCHEMA, UserSchema);
module.exports = UserModel;
