const roleOperations = require("../db/services/role_operations");
module.exports = {
  async addRole(request, response) {
    let roleData = request.body;
    try {
      let doc = await roleOperations.add(roleData);
      response.status(200).json({ doc: doc });
    } catch (err) {
      response.status(500).json({ err: err });
    }
  },
};
