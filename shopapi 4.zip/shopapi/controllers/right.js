const rightOperations = require("../db/services/right_operations");
module.exports = {
  async addRight(request, response) {
    let rightData = request.body;
    try {
      let doc = await rightOperations.add(rightData);
      response.status(200).json({ doc: doc });
    } catch (err) {
      response.status(500).json({ err: err });
    }
  },
};
