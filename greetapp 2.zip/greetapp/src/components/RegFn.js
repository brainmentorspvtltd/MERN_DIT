import { useRef, useState } from "react";
// Fn Component
export const RegFn = () => {
  console.log("Reg FN CALL");
  const [userInfo, setUserInfo] = useState({});
  const name = useRef();
  const age = useRef();
  const city = useRef();
  const phone = useRef();
  //const userInfo = {};
  const getAllValues = () => {
    let uname = name.current.value;
    let uage = age.current.value;
    let ucity = city.current.value;
    let uphone = phone.current.value;
    // userInfo.name = name.current.value;
    // userInfo.age = age.current.value;
    // userInfo.city = city.current.value;
    // userInfo.phone = phone.current.value;
    setUserInfo({ name: uname, age: uage, city: ucity, phone: uphone });
    console.log("UserInfo ", userInfo);
  };
  return (
    <>
      <p>User Info is {JSON.stringify(userInfo)}</p>
      <p>UseRef Example</p>
      <input type="text" ref={name} placeholder="Type Name Here" />
      <br />
      <input type="text" ref={age} placeholder="Type Age Here" />
      <br />
      <input type="text" ref={city} placeholder="Type City Here" />
      <br />
      <input type="text" ref={phone} placeholder="Type Phone Here" />
      <button onClick={getAllValues}>Register</button>
    </>
  );
};
