import React from "react";
export class Reg extends React.Component {
  constructor() {
    super();
    this.user = {};
    this.name = React.createRef();
    this.age = React.createRef();
    this.city = React.createRef();
    this.phone = React.createRef();
    console.log("This is ", this);
  }
  getAllValues() {
    // this.refs.name.value
    this.user.name = this.name.current.value;
    this.user.age = this.age.current.value;
    this.user.city = this.city.current.value;
    this.user.phone = this.phone.current.value;
    console.log("User Info is ", this.user);
  }
  render() {
    return (
      <div>
        {/* <input type="text" ref="name"/> */}
        <input type="text" ref={this.name} placeholder="Type Name Here" />
        <br />
        <input type="text" ref={this.age} placeholder="Type Age Here" />
        <br />
        <input type="text" ref={this.city} placeholder="Type City Here" />
        <br />
        <input type="text" ref={this.phone} placeholder="Type Phone Here" />
        <button onClick={this.getAllValues.bind(this)}>Register</button>
      </div>
    );
  }
}
