import { Reg } from "./components/Reg";
import { RegFn } from "./components/RegFn";
import { Greet } from "./containers/Greet";

export const App = () => {
  return (
    // <Greet/>
    <RegFn />
  );
};
