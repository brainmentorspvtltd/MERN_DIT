import React, { Component } from "react";
import { Input } from "../components/Input";
import { Operations } from "../components/Operations";
import { Output } from "../components/Output";
import { Title } from "../components/Title";
export class Greet extends Component {
  constructor() {
    super();
    this.msg = "";
    this.count = 0;
    this.inputs = {
      first: "",
      last: "",
    };
    this.message = "";
    this.state = { message: this.message, a: 10, b: 20 };
    console.log("State ", this.state);
  }
  // aMiT
  properCase(str) {
    return str.charAt(0).toUpperCase() + str.substring(1).toLowerCase();
  }
  sayWelcome() {
    let firstName = this.properCase(this.inputs["first"]);
    let lastName = this.properCase(this.inputs["last"]);
    this.message = `Welcome ${firstName} ${lastName}`;
    this.setState({ ...this.state, message: this.message });
    console.log(this.message);
  }
  takeInput(event, key) {
    //console.log('Rec Event ',event.target.value, 'Key ',key, ' This is ', this.inputs);
    this.inputs[key] = event.target.value;
    //console.log("Greet Input Fn call ",this.inputs);
  }
  callMe() {
    this.count++;
    console.log("I am Call Me ", this.count);
  }
  giveMeInput(event) {
    let val = event.target.value;
    this.msg = val;
    console.log("Val is ", this.msg);
  }
  render() {
    console.log("Render Called...");
    return (
      <div className="container">
        <Title />
        <input type="text" onChange={this.giveMeInput.bind(this)} />
        <Input
          name="first"
          input={this.takeInput.bind(this)}
          txt="First Name"
        />
        <Input name="last" input={this.takeInput.bind(this)} txt="Last Name" />
        <br />
        <button onClick={this.callMe.bind(this)}>Event Bind Examples </button>
        <button
          onClick={() => {
            console.log("Arrow Define in Event Binding...");
          }}
        >
          Event Bind Examples 2
        </button>
        <button
          onClick={() => {
            this.callMe();
          }}
        >
          Event Bind Examples 3
        </button>
        <Operations
          call={this.sayWelcome.bind(this)}
          myclass="btn-primary"
          text="Greet"
        />{" "}
        &nbsp;
        <Operations myclass="btn-secondary" text="Clear All" />
        <Output msg={this.state.message} />
      </div>
    );
  }
}
/*
export const Greet = ()=>{
    return (<div className='container'>
        <Title/>
        <Input txt="First Name"/>
        <Input txt="Last Name"/>
        <br/>
        <Operations myclass="btn-primary" text="Greet"/> &nbsp;
        <Operations myclass="btn-secondary" text="Clear All"/>
        <Output/>
    </div>)
}*/
