const CONFIG = {
    APPID:'583052006465476',
    VERSION:'v11.0',
    BASE_URL :'https://infinite-lake-18010.herokuapp.com',
    ROUTES:{
        LOGIN_FB:`${this.BASE_URL}/login`
    }

}