/**
 * User Route
 * @author Amit Srivastava
 * @version 1.0
 *
 */
const express = require("express");
const routes = express.Router();
const { DASHBOARD, LOGIN, GET_CONVO } = require('../utils/config').ROUTES;
const controller = require('../controllers/user');
routes.get(DASHBOARD, controller.dashboard);
routes.post(LOGIN, controller.facebookLogin);
routes.post(GET_CONVO, controller.getConvo);


module.exports = routes;



//const passport = require("../utils/oauth");
// routes.get(LOGIN_FB, passport.authenticate("facebook"));
// routes.get(
//   FB_CALLBACK,
//   passport.authenticate("facebook", { failureRedirect: "/" }),
//   controller.facebookLogin
// );