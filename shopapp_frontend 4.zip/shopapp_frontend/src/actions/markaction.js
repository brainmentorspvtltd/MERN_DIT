export const markAction = (type, data) => {
  return {
    type: type,
    payload: data,
  };
};
