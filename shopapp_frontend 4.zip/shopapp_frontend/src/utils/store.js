import { createStore } from "redux";
import { countReducer } from "./reducers/count_reducer";
export const store = createStore(countReducer);
store.subscribe(() => {
  console.log("Central Store Updated ... ", store.getState());
});
