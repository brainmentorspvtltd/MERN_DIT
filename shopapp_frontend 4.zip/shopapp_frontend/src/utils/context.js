import React from "react";
export const DataContext = React.createContext({
  markCount: 0,
  getMarkCount: function (val) {},
});
