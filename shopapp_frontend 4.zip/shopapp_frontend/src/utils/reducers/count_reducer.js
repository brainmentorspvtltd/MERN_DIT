// Operation on Total , Mark , UnMark

export const countReducer = (state = { markCount: 0 }, action) => {
  if (action.type == "MARK-INCREMENT") {
    let markCount = state.markCount;
    markCount = markCount + action.payload.step;
    return { ...state, markCount: markCount };
  }
  return state;
};
