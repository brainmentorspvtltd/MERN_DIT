import React from "react";
import { DataContext } from "../../utils/context";
import { connect } from "react-redux";
const Counts = (props) => {
  console.log("I am Counts Render");
  return (
    <>
      <h3>
        Total Records {props.total} Marked Records {props.countMark} Unmarked
        Records
      </h3>
      {/* <DataContext.Consumer>
        {(value) => {
          return (
            <h3>
              Total Records {total} Marked Records {value.markCount} Unmarked
              Records
            </h3>
          );
        }}
      </DataContext.Consumer> */}
    </>
  );
};

const mapStateToProps = (centralState) => {
  return {
    countMark: centralState.markCount,
  };
};
export default connect(mapStateToProps)(Counts);
