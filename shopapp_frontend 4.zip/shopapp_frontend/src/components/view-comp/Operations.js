import React from "react";

export const Operations = (props) => {
  return (
    <>
      <div className="row">
        <div className="col">
          <div className="form-group">
            <label>Search</label>
            <input type="range" className="form-range" />
          </div>
        </div>
        <div className="col">
          <div className="form-group">
            <label>Sort By</label>
            <select className="form-control">
              <option>Select Sort</option>
              <option>Sort By Name</option>
              <option>Sort By Price</option>
            </select>
          </div>
        </div>
      </div>
    </>
  );
};
