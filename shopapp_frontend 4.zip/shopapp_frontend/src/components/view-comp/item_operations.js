import React from "react";
import { markAction } from "../../actions/markaction";
import { productOperations } from "../../services/product_operations";
import { DataContext } from "../../utils/context";
import { store } from "../../utils/store";

export const ItemOperations = ({ pid, toggleMarking, getMarkCount }) => {
  const marking = () => {
    let marked = productOperations.mark(pid);
    toggleMarking(marked);
    store.dispatch(markAction("MARK-INCREMENT", { step: marked ? 1 : -1 }));
    //value.getMarkCount(productOperations.totalMarked());
  };
  console.log("I am Item Operation Render");
  return (
    <>
      <button className="btn btn-success">Edit</button>
      <button onClick={marking} className="btn btn-danger">
        Delete
      </button>
    </>
  );
  {
    /* <DataContext.Consumer>
        {(value) => {
          return (
            <>
              <button className="btn btn-success">Edit</button>
              <button
                onClick={() => {
                  marking(value);
                }}
                className="btn btn-danger"
              >
                Delete
              </button>
            </>
          );
        }}
      </DataContext.Consumer> */
  }
};
