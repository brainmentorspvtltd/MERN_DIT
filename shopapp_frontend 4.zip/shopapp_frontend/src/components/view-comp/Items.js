import React from "react";
import { DataContext } from "../../utils/context";
import { Item } from "./Item";

export const Items = (props) => {
  console.log("I am Items Render");
  return (
    <>
      <DataContext.Consumer>
        {(value) => {
          return <p>ITEMS ::: Mark Count is {value.markCount}</p>;
        }}
      </DataContext.Consumer>
      {props.items.map((item) => (
        // <Item getMarkCount={props.getMarkCount} item={item} />
        <Item item={item} />
      ))}
    </>
  );
};
