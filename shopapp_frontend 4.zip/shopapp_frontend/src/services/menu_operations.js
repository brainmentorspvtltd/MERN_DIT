import { Menu } from "../models/menu";

export const menuOperations = {
  fetchMenu() {
    // Make a Server Call and get the Menu Data from the BackEnd
    return [
      new Menu("Add", "/add/Amit/Delhi"),
      new Menu("View", "/views?name=Ram&city=Delhi"),
    ];
  },
};
