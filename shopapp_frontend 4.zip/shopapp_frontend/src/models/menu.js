export class Menu {
  constructor(name, link) {
    this.name = name;
    this.link = link;
  }
}
