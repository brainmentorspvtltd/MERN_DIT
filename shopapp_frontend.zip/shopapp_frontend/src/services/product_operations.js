export const productOperations = {
  products: [],
  addProduct(product) {
    this.products.push(product);
    return this.products.length;
  },
  getProducts() {
    return this.products;
  },
};
