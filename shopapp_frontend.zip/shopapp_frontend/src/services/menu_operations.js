import { Menu } from "../models/menu";

export const menuOperations = {
  fetchMenu() {
    // Make a Server Call and get the Menu Data from the BackEnd
    return [new Menu("Add", "/add"), new Menu("View", "/views")];
  },
};
