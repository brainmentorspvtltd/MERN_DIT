import React, { useEffect, useState } from "react";
import { productOperations } from "../services/product_operations";
import { Items } from "./view-comp/Items";
import { Operations } from "./view-comp/Operations";

export const View = (props) => {
  const [products, setProducts] = useState([]);
  const [total, setTotal] = useState(0);
  useEffect(() => {
    console.log("View Component Loaded..");
    let prods = productOperations.getProducts();
    setProducts(prods);
    setTotal(prods.length);

    //total = 10;
  }, []);
  const printProducts = (products) => {
    return (
      <>
        <Operations />
        <Items items={products} />
      </>
    );
  };

  return (
    <div className="container">
      <h1>Total Items are {total}</h1>
      {total == 0 ? <p>No record found</p> : printProducts(products)}
    </div>
  );
};
