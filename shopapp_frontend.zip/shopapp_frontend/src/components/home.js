import React from "react";

export const Home = (props) => {
  return (
    <>
      <h1>I am the Home</h1>
    </>
  );
};
