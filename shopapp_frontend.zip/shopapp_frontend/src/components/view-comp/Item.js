import React from "react";
import { ItemOperations } from "./item_operations";

export const Item = (props) => {
  return (
    <div>
      <p>Name {props.item.name}</p>
      <p>Desc {props.item.desc}</p>
      <p>Price {props.item.price}</p>
      <ItemOperations />
    </div>
  );
};
