import React from "react";

export const Counts = (props) => {
  return (
    <>
      <p>Total Records Marked Records Unmarked Records</p>
    </>
  );
};
