import React from "react";

export const ItemOperations = (props) => {
  return (
    <>
      <button className="btn btn-success">Edit</button>
      <button className="btn btn-danger">Delete</button>
    </>
  );
};
