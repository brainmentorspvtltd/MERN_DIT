import React, { useEffect, useState } from "react";
import { menuOperations } from "../services/menu_operations";
import { Link, NavLink } from "react-router-dom";

export const Menu = (props) => {
  const [menus, setMenu] = useState([]);
  useEffect(() => {
    let menuList = menuOperations.fetchMenu();

    setMenu(menuList);
  }, []);
  const printMenu = (menu, index) => {
    return (
      <li key={index} className="nav-item">
        <NavLink activeClassName="active" to={menu.link}>
          <span data-feather="file"></span>
          {menu.name}
        </NavLink>
      </li>
    );
  };
  //   if (menus.length == 0) {
  //     return <span>No Menu You Have</span>;
  //   } else {
  //     let dashBoardMenus = menus.map((menu, index) => printMenu(menu, index));
  //     console.log(dashBoardMenus);
  //     return <>{dashBoardMenus}</>;
  //   }
  return (
    <>
      {menus.length == 0 ? <span>No Menu You Have</span> : menus.map(printMenu)}
    </>
  );
};
