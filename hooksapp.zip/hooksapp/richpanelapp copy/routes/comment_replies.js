const express = require('express');
const router = express.Router();
const requestmod = require('request');
router.get('/posts',async (request, response)=>{
    const posts= [];
    const replies = [];
    try{
    const result = await requestmod(`graph.facebook.com/v11.0/${process.env.PAGE_ID}/feed`);
    if(result && result.data){
        console.log("Result is ",result, " Type ",typeof result.data);
         result.data.forEach(post=>{
             if(post.message){

                posts.push(post);
             }
         })
    }
    if(posts.length>0){
        posts.forEach(post=>{
            const comments = await requestmod(`graph.facebook.com/v11.0/${post.id}/comments`);
            if(comments && comments.data){
                post.comments = comment.data;
                post.comments.forEach()
                const replie = await requestmod(`graph.facebook.com/v11.0/${comments.id}/comments`);
                if(replie && replie.data){
                    post.comment.replies = replie.data;
                }

            }
        })
    }
    const json = {"post":posts};
    response.status(200).json(json);
}
    catch(err){
        console.log('Error During Post , Comment , replies fetch ', err);
    }
});
