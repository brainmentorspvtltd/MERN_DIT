import React, { useRef } from "react";
import { Product } from "../models/product";
import { productOperations } from "../services/product_operations";
export const Add = (props) => {
  const id = useRef();
  const name = useRef();
  const price = useRef();
  const desc = useRef();
  const url = useRef();
  const addProduct = () => {
    var product = new Product(
      id.current.value,
      name.current.value,
      desc.current.value,
      price.current.value,
      url.current.value
    );
    var len = productOperations.addProduct(product);
    console.log(len, productOperations.products);
    // let product = {
    //   id: id.current.value,
    //   name: name.current.value,
    //   price: price.current.value,
    //   desc: desc.current.value,
    //   url: url.current.value,
    // };
  };
  console.log(" PROPS ", props);
  return (
    <div className="container">
      <p>
        Param Rec {props.match.params.name} and {props.match.params.city}
      </p>
      <h1 className="alert-info">Add Product Screen</h1>
      <div className="form-group">
        <label>Id</label>
        <input
          className="form-control"
          type="text"
          placeholder="Type Id Here"
          ref={id}
        />
      </div>
      <div className="form-group">
        <label>Name</label>
        <input
          className="form-control"
          type="text"
          ref={name}
          placeholder="Type Name Here"
        />
      </div>
      <div className="form-group">
        <label>Desc</label>
        <textarea
          className="form-control"
          placeholder="Type Desc Here"
          ref={desc}
          rows="5"
          cols="20"
        ></textarea>
      </div>
      <div className="form-group">
        <label>Price</label>
        <input
          ref={price}
          className="form-range"
          type="range"
          min="1"
          max="1000"
        />
      </div>
      <div className="form-group">
        <label>URL</label>
        <input
          ref={url}
          className="form-control"
          type="text"
          placeholder="Type URL Here"
        />
      </div>
      <br />
      <div className="form-group">
        <button onClick={addProduct} className="btn btn-primary">
          Add
        </button>{" "}
        &nbsp;
        <button className="btn btn-secondary">Clear All</button>
      </div>
    </div>
  );
};
