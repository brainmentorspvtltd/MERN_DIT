// Glue b/w View and Model
window.addEventListener('DOMContentLoaded',bindEvents);
function bindEvents(){
    document.querySelector("#add").addEventListener('click', addTask);
}
function addIcon(imageName){
    let img = document.createElement('img');
    img.src = `assets/images/${imageName}.png`;
    img.className='size mr-2';
    return img;
}
function printTask(todoObject){
    let tbody = document.querySelector('#tasks');
    let tr = tbody.insertRow();
    let index = 0;
    for(let key in todoObject){
        tr.insertCell(index).innerText = todoObject[key];
        index++;
    }
    let td = tr.insertCell(index);
    td.appendChild(addIcon('edit'));
    td.appendChild(addIcon('delete'));
}
function addTask(){
      const tempObject = {tid:0, name:'', desc:'', date:'', url:'', pr:''};
      for(let key in tempObject){
        tempObject[key] =  document.querySelector("#"+key).value;
      }  
      console.log(tempObject);
      const todoObject = TODO_OPERATIONS.add(tempObject);
      printTask(todoObject);

//    let id =  document.querySelector("#tid").value;
//    let name =  document.querySelector("#name").value;
//    let desc =  document.querySelector("#desc").value;
//    let date =  document.querySelector("#date").value;
//    let url =  document.querySelector("#url").value;
//    let pr =  document.querySelector("#pr").value;


}
