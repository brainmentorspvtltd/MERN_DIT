const TODO_OPERATIONS = {
    tasks:[],
    add({tid, name, desc, date,url, pr}){
       let todo = new Todo(tid, name, desc, date, url,pr);     
        this.tasks.push(todo);
        return todo;
    },
    remove(){

    },
    search(){

    },
    update(){

    },
    sort(){

    },
    read(){
        
    }
    
}