function ajax(){
    const URL = 'https://raw.githubusercontent.com/brainmentorspvtltd/mydata/main/server.json';
    return fetch(URL);
}