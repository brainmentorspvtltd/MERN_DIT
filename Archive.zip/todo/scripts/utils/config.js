const FIELDS = {
    id:"number",
    name:"string",
    desc:"string"
}