function getSongsBySingerModern(singerName){
    const URL = `https://itunes.apple.com/search?term=${singerName}&limit=10`;
    // fetch(URL,{
    //     method:'GET',

    //     //body for post
    //     //headers
    // })
    const promise = fetch(URL);
    return promise;
}
function getSongsBySinger(singerName, convert){
    var xmlHttpRequest = new XMLHttpRequest();
    const URL = `https://itunes.apple.com/search?term=${singerName}&limit=10`;
    console.log('Before Ready State');
    xmlHttpRequest.onreadystatechange = function(){
        console.log('Ready State Call ', this.readyState);
        if(this.readyState==4 && this.status==200){
            document.querySelector('#loading').className='hide';
            console.log('Data Rec ', this.responseText, ' Type ', this.responseType);
            console.log(typeof this.responseType);
            convert(this.responseText);
        }
    }
    xmlHttpRequest.open('GET',URL,true);
    xmlHttpRequest.send(null);
    console.log('After Send ...');
    // if(window.XMLHttpRequest){ // Chrome , FF

    // }
    // else{
    //     window.ActiveXObject() ; // Old IE Browser
    // }
}