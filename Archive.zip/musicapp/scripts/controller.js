window.addEventListener('load', bindEvents);
function bindEvents(){
    document.querySelector('#search').addEventListener('click', searchBySinger);
}
function searchBySinger(){
    let singerName  = document.querySelector('#singer').value;
    if(singerName && singerName.length>0){
        document.querySelector('#loading').className='';
        //getSongsBySinger(singerName, convert);
       const promise=  getSongsBySingerModern(singerName);
       promise.then(response=>{
           response.json().then(songs=>{
            document.querySelector('#loading').className='hide';
                printSongs(songs['results']);
           }).catch(err=>{
               console.log('Invalid JSON ', err);
           }).catch(err=>{
               console.log('Unable to connect to the Server ',err);
           })
       });
    }
}
function convert(json){
    console.log('Before Convert ', json);
    let songs = JSON.parse(json);
    console.log('After Convert ', songs);
    const allSongs = songs['results'];
    printSongs(allSongs);
}
function printSongs(allSongs){
    let outputDiv = document.querySelector('#output');
    outputDiv.innerHTML = '';
    allSongs.forEach(song=>{
        let div = document.createElement('div');
        let img = document.createElement('img');
        img.src=song['artworkUrl100'];
        div.appendChild(img);
        let audio = document.createElement('audio');
        audio.style.width = '500px';
        audio.controls=true;
        audio.src=song['previewUrl'];
        div.appendChild(audio);
        outputDiv.appendChild(div);
    })
}