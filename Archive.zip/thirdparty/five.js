var cname = "Amit";
//console.log("Your Name is ",cname);
console.log("Your Name is %s",cname);
const util = require("util");

const obj = {
    name:"Amit",
    company:{
        name:"Brain Mentors",
        city:"Delhi",
        courses:
            {name:'JS',duration:1}


    }
}
console.log(util.inspect(obj,{depth:1}));
//console.dir(obj,{depth:2});
//console.log(global);