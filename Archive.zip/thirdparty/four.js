const prompt = require('prompt-sync')();
const chalk = require('chalk');
let name = prompt("Enter your Name");
console.log(chalk.red.bold("Your Name is "),chalk.green.italic(name));
let age= prompt("Enter Your Age");
console.log(chalk.blue("Age is "),chalk.yellow(age));