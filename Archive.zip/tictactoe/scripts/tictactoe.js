window.addEventListener('load', bindEvent);
function bindEvent(){
   let buttons= document.getElementsByTagName('button');
   Array.prototype.forEach.call(buttons, (button)=>button.addEventListener('click', printXorZero ));
}

let flag = true;
function printXorZero(){
    console.log('PrintX Or Zero ',this);
    let button = this;
    if(button.innerText.length==0){
    button.innerText = (flag === true?'X':'0');
    flag = !flag;
    }

}