console.log('Hello Node');
console.log(__dirname);
console.log(__filename);
console.log(process.env.USER);
//console.log(Buffer);
//setTimeout(()=>console.log('I will call after 5 sec'),5000);
const t = setInterval(()=>console.log("I will every 2 sec"),2000);
setTimeout(()=>clearInterval(t),7000);
//clearTimeout
console.log(module.exports);