//console.log(process.argv);
// var x = parseInt(process.argv[2]);
// var y = parseInt(process.argv[3]);
// var z  = x + y;
// console.log(z);
let db = '';
if(process.argv[2]=='dev'){
    db = 'localpath';
}
else if(process.argv[2]=='prod'){
    db ='clouddb';
}
console.log('Selected db is ',db);