//console.log('Hello Node');
//process.stdout.write("Hello Node\n");
let data = '';
process.stdin.on('data',chunk=>{
    data+=chunk;
    console.log(data);
});
// process.stdout.on('end',chunk=>{
//    console.log(data);
// })
