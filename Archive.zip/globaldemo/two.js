console.log(process.cwd());
console.log(process.env);
process.on('uncaughtException',err=>{
    process.kill(process.pid);
    console.log('Error is ',err);
})
++a;
process.on('exit',code=>{
    console.log('Code is ',code, 'Id is ',process.pid);
})
