const express = require('express');
const path = require('path');
const app = express();
const expressSession = require('express-session');
app.use(express.static('public'));
app.use(express.urlencoded());
app.use(express.json());
app.set('view engine','ejs');
//app.set('views','templateFolderPath')
app.use(expressSession({
    secret:'thisissecret',
    maxAge:2*60*1000,
    secure:false,
    cookie:{maxAge:24*60*60*1000}
}));
app.get('/logout',async (request, response)=>{
    if(request.session && request.session.userid){
        await request.session.destroy();
        response.send("Logout SuccessFully");
    }
});
app.post('/login',(request, response)=>{
    let userid = request.body.userid;
    let password = request.body.pwd;
    if(userid === password){
        request.session.userid = userid;
        response.redirect("/dashboard?userid="+userid+"&age=21");
       // response.send("Welcome "+userid);
    }
    else{
        response.send("Invalid Userid or Password");
    }
});

app.get('/dashboard',(request, response)=>{
    if(request.session && request.session.userid){
   // let userid = request.query.userid;
    //let age = request.query.age;
    //console.log('Userid ',userid, 'Age ',age);
    const fullPath = path.join(__dirname,'public/dashboard.html');
    //response.sendFile(fullPath);
    response.render('dashboard',{userid:request.session.userid});
    }
    else{

        response.sendFile(path.join(__dirname,'public/login.html'));
    }

})
//console.log(typeof express, typeof app);
const server = app.listen(1234,(err)=>{
    if(err){
        console.log('Error in Server Start');
    }
    else{
        console.log('Server Started ',server.address().port);
    }
})
