const jwt = require("../utils/token");
const messageBundle = require("../locales/en.json");
const { RESOURCE_NOT_FOUND } = require("../utils/config").STATUS_CODES;
module.exports = (request, response, next) => {
  const authHeader = request.headers["authorization"];
  if (authHeader) {
    const decoded = jwt.verifyToken(authHeader);
    if (decoded && decoded.email) {
      next();
    } else {
      response
        .status(RESOURCE_NOT_FOUND)
        .json({ message: messageBundle["user.token.invalid"] });
    }
  } else {
    response
      .status(RESOURCE_NOT_FOUND)
      .json({ message: messageBundle["user.token.invalid"] });
  }
};
