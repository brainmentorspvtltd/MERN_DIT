const express = require("express");
const router = express.Router();
router.get("/paymenthistory", (request, response) => {
  response.send("Payment History");
});
module.exports = router;
