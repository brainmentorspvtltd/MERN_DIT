/**
 * This is the Application file , all the middleware settings are here
 * Server is start from Here
 * @author Amit Srivastava
 * @version 1.0
 * @copyright Brain Mentors
 */
const express = require("express");
const app = express();
const dotenv = require("dotenv");
const morgan = require("morgan");
dotenv.config();
const serverLogStream = require("./utils/logs/serverlogger");
const logger = require("./utils/logs/logger")(__filename);

app.use(morgan("combined", { stream: serverLogStream }));
app.use(express.urlencoded());
app.use(express.json());
app.use("/", require("./api/v1.0/routes/user"));
app.use(require("./middlewares/token-auth"));
app.use("/", require("./api/v1.0/routes/order"));
app.use("/", require("./api/v1.0/routes/payments"));

const server = app.listen(process.env.PORT || 1234, (err) => {
  if (!err) {
    console.log("Server Started...", server.address().port);
    logger.debug("Server Started " + server.address().port);
  } else {
    logger.error("Unable to Start the Server " + JSON.stringify(err));
  }
});
