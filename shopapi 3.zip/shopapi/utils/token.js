const jwt = require("jsonwebtoken");

module.exports = {
  generateToken(emailId) {
    return jwt.sign({ email: emailId }, process.env.JWT_SECRET, {
      expiresIn: "1h",
    });
  },
  verifyToken(tokenId) {
    let decoded = jwt.verify(tokenId, process.env.JWT_SECRET);
    return decoded;
  },
};
