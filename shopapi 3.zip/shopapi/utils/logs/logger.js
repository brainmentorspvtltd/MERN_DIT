const winston = require("winston");
const { MAX_FILES, MAX_SIZE, DEBUG_LOG_FILE, ERROR_LOG_FILE } =
  require("../config").LOGS;
const { combine, label, timestamp, printf } = winston.format;
const customFormat = printf(({ level, message, label, timestamp }) => {
  return `${level} :: ${label} ===> ${message} TIME :: ${timestamp}`;
});
module.exports = function (moduleName) {
  const logger = winston.createLogger({
    level: "debug",
    format: combine(label({ label: moduleName }), timestamp(), customFormat),
    transports: [
      new winston.transports.File({
        filename: ERROR_LOG_FILE,
        level: "error",
        maxsize: MAX_SIZE,
        maxFiles: MAX_FILES,
      }),
      new winston.transports.File({
        filename: DEBUG_LOG_FILE,
        level: "debug",
        maxsize: MAX_SIZE,
        maxFiles: MAX_FILES,
      }),
    ],
  });
  return logger;
};
