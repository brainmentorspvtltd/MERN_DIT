/**
 * This is for USER CRUD Operations
 * @author Amit Srivastava
 * @version 1.0
 * @copyright Brain Mentors
 */
const UserModel = require("../models/user");
const encryption = require("../../utils/encrypt");
module.exports = {
  add(user) {
    user.password = encryption.encrypt(user.password);
    const promise = UserModel.create(user);
    return promise;
  },
  async find(user) {
    try {
      let document = await UserModel.findOne({
        email: user.email,
      });
      if (document && document.email) {
        if (encryption.comparePassword(user.password, document.password)) {
          return document;
        } else {
          return null;
        }
      }
    } catch (err) {
      throw err;
    }
  },
  update() {},
  remove() {},
};
